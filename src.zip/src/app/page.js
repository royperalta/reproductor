import { Header } from './components/Header'
import Contenido from './components/Contenido'
import Footer from './components/Footer'



export default function Home() {  

  return (
    <main className="">
      <div>
        <Header />       
        <Contenido />  
        <Footer />   
      </div>
    </main>
  )
}

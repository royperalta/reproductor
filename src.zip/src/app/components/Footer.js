export default function Footer(){
    return(
        <div>
            Pie de página
        </div>
    )
}
export function Titulo(props){
    return(
        <div className="w-3/4">
           {props.titulo}
        </div>
    )
}
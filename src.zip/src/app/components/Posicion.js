export function Posicion(props){
    return(
        <div className="w-10">
           {props.position}
        </div>
    )
}
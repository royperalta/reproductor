'use client'

import { useEffect, useState } from "react"
import { Posicion } from "./Posicion"
import { Titulo } from "./Titulo"
import { Foto } from "./Foto"
import Cancion from "./Cancion"

export default function Contenido() {

    const [data, setData] = useState([])

    useEffect(() => {
        fetch('http://localhost:20000/api/info')
            .then(info => info.json())
            .then(info => setData(info))
    }, [])

    return (
        <div className="w-4/5 mx-auto">
            {data.map((cancion, index) => (
                <div key={index} className="flex">
                    <Posicion position={cancion.position} /> 
                    <Foto url_image={cancion.url_image}/>  
                    <Titulo titulo={cancion.titulo} />                     
                    <Cancion url_audio={cancion.url_audio} />                   
                </div>
            ))}
        </div>
    )
}
export default function Contacto(){
    return(
        <div>
            Contacto
            Esta la paginas de contactos
        </div>
    )
}
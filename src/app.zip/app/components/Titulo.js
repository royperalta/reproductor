export function Titulo(props){
    return(
        <div className="w-3/4 flex items-center justify-start px-4">
           {props.titulo}
        </div>
    )
}
export default function Cancion(props) {

    return (
        <div>           
            <div className="">
                <audio controls>
                    <source src={props.url_audio} type="audio/mp4" />
                </audio>
            </div>
        </div>
    )
}